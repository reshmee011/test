import { WebPartContext } from '@microsoft/sp-webpart-base';
import { spfi,SPFx,SPFI } from '@pnp/sp';
import { TickerItem } from '../ticker/models/TickerItem';
import '@pnp/sp/sites';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';

import { IDataProvider } from './IDataProvider';

export class SPDataProvider implements IDataProvider {
    private sp: SPFI;
    
    public constructor(context: WebPartContext, siteUrl?: string) {
        this.sp = spfi(siteUrl).using(SPFx(context));
    }

    public async loadListItems(listTitle: string, fields: string[]): Promise<TickerItem[]> {
        const data = await this.sp.web.lists.getByTitle(listTitle).items
            .select(...fields)
            ();

        const items = data.map(i => new TickerItem());

        return items;
    }

    public async loadLists(): Promise<string[]> {
        const data = await this.sp.web.lists.select('Title').filter('Hidden eq false')();
        const lists = data.map(l => l.Title);
        return lists;
    }

    public async loadColumnFormatting(listTitle: string, fieldName: string): Promise<unknown> {
        const data = await this.sp.web.lists.getByTitle(listTitle).fields.getByInternalNameOrTitle(fieldName)();
        const parser = new DOMParser();
        const doc = parser.parseFromString(data.SchemaXml, 'application/xml');
        const formatter = doc.getElementsByTagName('Field')[0].getAttribute('CustomFormatter');
        return JSON.parse(formatter as string);
    }
}