import { TickerItem } from '../ticker/models';

export interface IDataProvider {
    loadListItems(listTitle: string, fields: string[]): Promise<TickerItem[]>;
    loadLists(): Promise<string[]>;
    loadColumnFormatting(listTitle: string, fieldName: string): Promise<unknown>;
}