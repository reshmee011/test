export interface IDictionary<T> {
    [key: string]: T;
}