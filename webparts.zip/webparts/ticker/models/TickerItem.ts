export class TickerItem {
    id:number;
    applicationName:string;
    notes:string;
}