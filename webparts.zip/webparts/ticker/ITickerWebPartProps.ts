import { IPropertyFieldSite } from '@pnp/spfx-property-controls';

export interface ITickerWebPartProps {
    site: IPropertyFieldSite[];
    listName: string;
}