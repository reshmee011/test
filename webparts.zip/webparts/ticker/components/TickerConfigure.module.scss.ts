/* tslint:disable */
require("./TickerConfigure.module.css");
const styles = {
  configure: 'configure_61e1eb6f'
};

export default styles;
/* tslint:enable */