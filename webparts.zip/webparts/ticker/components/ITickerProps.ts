import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface ITickerProps {
  userDisplayName: string;
  context: WebPartContext;
}
