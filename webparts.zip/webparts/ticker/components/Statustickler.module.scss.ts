/* tslint:disable */
require("./Statustickler.module.css");
const styles = {
  tcontainer: 'tcontainer_e1c40da1',
  tickerWrap: 'tickerWrap_e1c40da1',
  tickerMove: 'tickerMove_e1c40da1',
  'vertical-tickerleft': 'vertical-tickerleft_e1c40da1',
  tickerItem: 'tickerItem_e1c40da1',
  statustickler: 'statustickler_e1c40da1',
  teams: 'teams_e1c40da1',
  callout: 'callout_e1c40da1',
  calloutTitle: 'calloutTitle_e1c40da1',
  calloutLink: 'calloutLink_e1c40da1',
  speechContainer: 'speechContainer_e1c40da1',
  details: 'details_e1c40da1',
  beak: 'beak_e1c40da1',
  welcome: 'welcome_e1c40da1',
  welcomeImage: 'welcomeImage_e1c40da1',
  links: 'links_e1c40da1',
  moveTickersleft: 'moveTickersleft_e1c40da1',
  moveTickersright: 'moveTickersright_e1c40da1'
};

export default styles;
/* tslint:enable */