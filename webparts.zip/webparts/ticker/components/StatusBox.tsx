import styles from './Ticker.module.scss';
import * as React from 'react';
import { useState, useEffect } from 'react';
import { Callout, DirectionalHint, Link, Text } from '@fluentui/react';
import { useBoolean, useId } from '@fluentui/react-hooks';
  
export function StatusBox({ status, appName, details }: { status: string, appName: string, details: string }): JSX.Element  {
    let backgroundColor, color,borderColor,borderLeftColor;
  
    const [isCalloutVisible, { toggle: toggleIsCalloutVisible }] = useBoolean(false);
    const detailsId = useId('callout-button');
    const labelId = useId('callout-label');
    const descriptionId = useId('callout-description');
    const [directionalHint, setDirectionalHint] = useState<DirectionalHint>(DirectionalHint.bottomLeftEdge);
    const [beakWidth, setBeakWidth] = useState<number>();
  
    const [mousePosition, setMousePosition] = useState<{x: number, y: number} | null>(null);
   
    const handleMouseEnter = (event: React.MouseEvent<HTMLElement>): void => {
     setMousePosition({ x: event.clientX, y: event.clientY });
     toggleIsCalloutVisible();
    };
  
    useEffect(() => {
      setBeakWidth(10);
      setDirectionalHint(DirectionalHint.bottomCenter);
    }, []);
  
    switch (status) {
      case 'red':
        backgroundColor = 'red';
        borderLeftColor = 'red';
        borderColor = 'red';
        color = 'white';
        break;
      case 'green':
        backgroundColor = 'green';
        borderLeftColor = 'green';
        borderColor = 'green';
        color = 'black';
        break;
      case 'amber':
        backgroundColor = '#FFBF00';
        borderLeftColor = '#FFBF00';
        borderColor = '#FFBF00';
        color = 'white';
        break;
      default:
        backgroundColor = 'white';
        borderLeftColor = 'black';
        borderColor = 'black';
        color = 'black';
    }
    return (
        <div id={detailsId} onMouseEnter={handleMouseEnter} onMouseLeave={toggleIsCalloutVisible} style={{ padding: '10px', borderRadius: '5px', display: 'flex', alignItems: 'center' }}>
        <div className={styles.speechContainer} style={{ backgroundColor, color}}> 
        <p>{appName}</p>
                <div className={styles.beak} style={{borderLeftColor}}/>
          </div>
      <div className={styles.details} style={{ borderColor, color:'black'}}>
        <p>{details}</p>
        </div>
      <Link href="https://www.google.com" target="_blank" className={styles.calloutLink}>
        Sample link
        </Link>
          {isCalloutVisible && (
            <Callout
              ariaLabelledBy={labelId}
              ariaDescribedBy={descriptionId}
              role="dialog"
              className={styles.callout}
              target={mousePosition ? { left: mousePosition.x, top: mousePosition.y, width: 0, height: 0 } : undefined}
              isBeakVisible={true}
              beakWidth={beakWidth}
              onDismiss={toggleIsCalloutVisible}
              directionalHint={directionalHint}
              setInitialFocus
            >
              <Text block variant="xLarge" className={styles.calloutTitle} id={labelId}>
                {appName}
              </Text>
              <Text block variant="small" id={descriptionId}>
                {details}
              </Text>
            </Callout>
          )}
        </div>
    );
  }
  