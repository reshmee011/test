/* tslint:disable */
require("./StatusTickerConfigure.module.css");
const styles = {
  configure: 'configure_188caf71'
};

export default styles;
/* tslint:enable */