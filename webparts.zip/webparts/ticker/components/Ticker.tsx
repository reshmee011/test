import styles from './Ticker.module.scss';
import type { ITickerProps} from './ITickerProps';
import * as React from 'react';
import { useState} from 'react';

import { StatusBox } from './StatusBox';
import { useGlobalContext } from '../core/Global.context';

export default function Ticker(props: ITickerProps): React.ReactElement {
  useGlobalContext();
//  const [filters, setFilters] = useState<IDictionary<string[]>>(webProps.filters.filter((f: { selected: string | any[]; }) => f.selected.length).reduce<IDictionary<string[]>>((obj: { [x: string]: any; }, value: { field: string | number; selected: any; }) => { obj[value.field] = value.selected; return obj }, {}));

   const items = useState([
     { appName: 'Application 6', details: 'Details 1 Details 1 Details 1 Details 1 Details 1', status: 'red' },
     { appName: 'Application 2', details: "The user couldn't update the objective status current. A workaround has been emailed to the effected users. A fix will be deployed within 1 week time. please check this link Application Status - People Matters (sharepoint.com)", status: 'green' },
     { appName: 'Application 3', details: 'Details 3', status: 'amber' },
   ])[0];
 
/*https://codesandbox.io/p/sandbox/horizontal-ticker-css-jpy7s?file=%2Findex.html%3A12%2C5-27%2C11*/
   return (
     <section className={`${styles.Ticker}`}>
       <div>
       <div className={styles.tcontainer}>
       <div className={styles.tickerWrap}>
     <div className={styles.tickerMove}>
         {items.map((item, index) => (
      <div className={styles.tickerItem} key={index}>
           <StatusBox  status={item.status} appName={item.appName} details={item.details} />
         </div>
         ))}
 
     </div>
   </div>
   </div>  
       </div>
     </section>
   );
 }