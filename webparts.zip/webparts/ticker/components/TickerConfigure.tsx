import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';

import styles from './TickerConfigure.module.scss';

export interface ITickerConfigureProps {
    context: WebPartContext
}

export function TickerConfigure(props: ITickerConfigureProps): React.ReactElement {
    function openPropertyPanel(e: React.MouseEvent<HTMLAnchorElement>): void {
        e.preventDefault();
        props.context.propertyPane.openDetails();
        props.context.propertyPane.open();
    }

    return (
        <div className={styles.configure}>
            <a href="#" onClick={openPropertyPanel}>Please click here to configure the webpart</a>
        </div>
    )
}