/* tslint:disable */
require("./Ticker.module.css");
const styles = {
  tcontainer: 'tcontainer_e7f01c98',
  tickerWrap: 'tickerWrap_e7f01c98',
  tickerMove: 'tickerMove_e7f01c98',
  'vertical-tickerleft': 'vertical-tickerleft_e7f01c98',
  tickerItem: 'tickerItem_e7f01c98',
  Ticker: 'Ticker_e7f01c98',
  teams: 'teams_e7f01c98',
  callout: 'callout_e7f01c98',
  calloutTitle: 'calloutTitle_e7f01c98',
  calloutLink: 'calloutLink_e7f01c98',
  speechContainer: 'speechContainer_e7f01c98',
  details: 'details_e7f01c98',
  beak: 'beak_e7f01c98',
  welcome: 'welcome_e7f01c98',
  welcomeImage: 'welcomeImage_e7f01c98',
  links: 'links_e7f01c98',
  moveTickersleft: 'moveTickersleft_e7f01c98',
  moveTickersright: 'moveTickersright_e7f01c98'
};

export default styles;
/* tslint:enable */