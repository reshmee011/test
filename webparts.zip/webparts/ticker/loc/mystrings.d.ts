declare interface ITickerWebPartStrings {
  GeneralGroupName: string;
  SiteUrlFieldLabel: string;
  ListFieldLabel: string;
}

declare module 'TickerWebPartStrings' {
  const strings: ITickerWebPartStrings;
  export = strings;
}
