define([], function() {
  return {
    "GeneralGroupName": "Application Status Settings",
    "SiteUrlFieldLabel": "Site Url",
    "ListFieldLabel": "Source List"
  }
});