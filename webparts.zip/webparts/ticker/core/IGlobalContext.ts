import { IDataProvider } from '../../services/IDataProvider';
import { ITickerWebPartProps } from '../ITickerWebPartProps';

export interface IGlobalContext {
    sp: IDataProvider;
    webProps: ITickerWebPartProps;
}