import * as React from 'react';
import { useContext, createContext } from 'react';
import { IGlobalProps } from './IGlobalProps';
import { IGlobalContext } from './IGlobalContext';

export const GlobalContext = createContext<IGlobalContext>({ } as IGlobalContext);

export const useGlobalContext = (): IGlobalContext => useContext<IGlobalContext>(GlobalContext);

export const GlobalProvider = (props: IGlobalProps): JSX.Element => {
    return (
        <GlobalContext.Provider value={{ sp: props.sp, webProps: props.webProps }}>
            {props.children}
        </GlobalContext.Provider>
    );
};