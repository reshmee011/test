import * as React from 'react';

import { IDataProvider } from '../../services/IDataProvider';
import { ITickerWebPartProps } from '../ITickerWebPartProps';

export interface IGlobalProps {
    children?: React.ReactNode;
    sp: IDataProvider;
    webProps: ITickerWebPartProps;
}