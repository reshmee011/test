import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import PnPTelemetry from '@pnp/telemetry-js';
import { IGlobalProps } from './core/IGlobalProps';
import { GlobalProvider } from './core/Global.context';
import * as strings from 'TickerWebPartStrings';
import Ticker from './components/Ticker';
import { ITickerProps } from './components/ITickerProps';
import { PropertyFieldSitePicker,IPropertyFieldSite } from '@pnp/spfx-property-controls';
import {IPropertyPaneConfiguration, IPropertyPaneDropdownOption, PropertyPaneDropdown} from '@microsoft/sp-property-pane';
import { IDataProvider } from '../services/IDataProvider';
import { SPDataProvider } from '../services/SPDataProvder';
import { ITickerWebPartProps } from './ITickerWebPartProps';

require('./core/colours.css');
require('./core/overrides.css');

export default class TickerWebPart extends BaseClientSideWebPart<ITickerWebPartProps> {

  private _spService: IDataProvider;
  private lists: IPropertyPaneDropdownOption[] = [];
  
  public async onInit(): Promise<void> {
    await super.onInit();
    PnPTelemetry.getInstance().optOut();
    this._spService = new SPDataProvider(this.context, this.properties.site.length ? this.properties.site[0].url : this.context.pageContext.web.absoluteUrl);
  }

  public render(): void {
    const element: React.ReactElement<ITickerProps> = React.createElement(
      Ticker,
      {
        userDisplayName: this.context.pageContext.user.displayName,
        context: this.context
      }
    );

  const provider: React.ReactElement<IGlobalProps> = React.createElement(
    GlobalProvider,
    {
      sp: this._spService,
      webProps: {
        site: this.properties.site,
        listName: this.properties.listName
      }
    },
    element
  );

  ReactDom.render(provider, this.domElement);
}

   protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected async onPropertyPaneConfigurationStart(): Promise<void> {
    if (this.properties.site.length) {
      this.lists = await this.loadLists();
    }
    this.context.propertyPane.refresh();
  }

  protected async onPropertyPaneFieldChanged(propertyPath: string, oldValue: unknown, newValue: unknown): Promise<void> {
    if (propertyPath === 'site') {
      const sites: IPropertyFieldSite[] = newValue as IPropertyFieldSite[];
      if (sites.length) {
        this._spService = new SPDataProvider(this.context, sites[0].url);
        this.lists = await this.loadLists();
      } else {
        this.lists = [];
      }
      this.context.propertyPane.refresh();
    } else {
      super.onPropertyPaneFieldChanged(propertyPath, oldValue, newValue);
    }
  }

  private async loadLists(): Promise<IPropertyPaneDropdownOption[]> {
    const lists = await this._spService.loadLists();
    const listOptions: IPropertyPaneDropdownOption[] = lists.map(l => ({ key: l, text: l }));
    return listOptions;
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          displayGroupsAsAccordion: true,
          groups: [
            {
              groupName: strings.GeneralGroupName,
              groupFields: [
                PropertyFieldSitePicker('site', {
                  label: 'Site',
                  multiSelect: false,
                  initialSites: this.properties.site,
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  context: this.context as any,
                  onPropertyChange: () => this.onPropertyPaneFieldChanged,
                  properties: this.properties,
                  key: 'site'
                }),
                PropertyPaneDropdown('listName', {
                  label: strings.ListFieldLabel,
                  options: this.lists,
                  disabled: !this.lists.length
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
